import { useState } from 'react'
import './App.css'
import Stopwatch from './components/Stopwatch'
import { Time } from './TimeType';

function App() {
  const [inicio, setInicio] = useState<boolean>(false);
  const [pausar, setPausar] = useState<boolean>(false);
  const [alarma, setAlarma] = useState<Time>({m: 0 , s: 0, h: 0})

  const handleSubmitIniciar = (e: any) => {
    e.preventDefault();
    setInicio(!inicio);
    if(inicio){
      setPausar(true);
    } else {
      setPausar (false);
    }
  }

  const handleSubmitAlarma = (e: any) => {
    e.preventDefault();
    console.log("Hola");
  }


  return (
    <>
      

      <form id='formIniciar' onSubmit={handleSubmitIniciar}>
        <button className=''>{!inicio ? "Iniciar Tiempo" : "Pausar Tiempo"}</button>
      </form>

      <form id='formIniciar' onSubmit={handleSubmitAlarma}>
        <input type="number" name="" id="" placeholder='horas' />
        <input type="number" name="" id="" placeholder='minutos' />
        <input type="number" name="" id="" placeholder='segundos' />
        <button className='' type='submit'>Enviar Alarma</button>
      </form>



      <br />


      <Stopwatch start={inicio} stop={pausar} />
    </>
  )
}

export default App
