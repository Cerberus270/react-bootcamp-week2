import React, { useRef, useState, useEffect } from 'react'
import { Time } from '../TimeType'

type StopwatchType = {
    start: boolean
    stop: boolean
    // reset: boolean
}


const Stopwatch = ({ start, stop }: StopwatchType) => {
    const [tiempo, setTiempo] = useState<Time>({ s: 0, m: 0, h: 0 });
    const ref = useRef<number>();

    function hola(): void {
        if (start && stop === false) {
            ref.current = setInterval(() => setTiempo((t) => {
                let s = t.s + 1;
                let m = t.m;
                let h = t.h
                if (s == 60) {
                    s = 0;
                    m = t.m + 1
                }
                if (m == 60){
                    m = 0;
                    h = t.h + 1; 
                }
                return { s, m, h }
            }), 1000);
        } else if (stop && start === false) {
            console.log("Hola");
            ref.current && clearInterval(ref.current);
        }
    }

    useEffect(() => {
        hola();
    }, [start, stop])

    // if(iniciar){
    //     ref.current && clearInterval(ref.current);
    //     ref.current = setInterval(() => setSegundos(s => s + 1), 1000);
    // }



    return (
        <>
            <h4>Timer:   <small>{tiempo.h}</small>: <small>{tiempo.m}</small>: <small>{tiempo.s}</small></h4>
        </>
    )
}

export default Stopwatch