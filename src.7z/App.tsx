import { useState } from 'react'
import './App.css'
import Stopwatch from './components/Stopwatch'

function App() {
  const [miliseconds, setMiliseconds] = useState<number>(1000);

  const handleSubmit = (e: any) => {
    e.preventDefault();
    // Read the form data
    const form = e.target;
    const formData = new FormData(form);


    const formJson = Object.fromEntries(formData.entries());
    console.log(formJson);
    //console.log(formJson.miliseconds);
    setMiliseconds(parseInt(formJson?.miliseconds as string));
  }

  return (
    <>
      <span>Milisegundos {1000}</span>

      <form onSubmit={handleSubmit}>
        <button className=''>Iniciar Tiempo</button>
      </form>


      <br />


      <Stopwatch mili={miliseconds} />
    </>
  )
}

export default App
