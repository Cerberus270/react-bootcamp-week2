import React, { useRef, useState, useEffect } from 'react'

type StopwatchType = {
    start: boolean
    stop: boolean
    reset: boolean
}
const Stopwatch = ({ start, stop, reset }: StopwatchType) => {
    const [iniciar, setIniciar] = useState<boolean>(false && start);
    const [segundos, setSegundos] = useState(0);
    const ref = useRef<number>();

    // useEffect(() => {
    //     ref.current && clearInterval(ref.current);
    //     ref.current = setInterval(() => setSegundos(s => s + 1), mili);
    // }, [mili])



    return (
        <>
            <h4>Timer: <small>{2}</small> <small>{segundos}</small></h4>
        </>
    )
}

export default Stopwatch