import React, { useRef, useState, useEffect } from 'react'
import { Time } from '../TimeType'

type StopwatchType = {
    start: boolean
    stop: boolean
    alarma: Time
    // reset: boolean
}


const Stopwatch = ({ start, stop, alarma }: StopwatchType) => {
    const [tiempo, setTiempo] = useState<Time>({ s: 0, m: 0, h: 0 });
    //const [alarmaCrono, setAlarmaCrono] = useState<Time>({ s: -1, m: -1, h: -1 });
    const ref = useRef<number>();

    function hola(): void {
        if (start && stop === false) {
            ref.current = setInterval(() => setTiempo((t) => {
                let s = t.s + 1;
                let m = t.m;
                let h = t.h
                if (s == 60) {
                    s = 0;
                    m = t.m + 1
                }
                if (m == 60) {
                    m = 0;
                    h = t.h + 1;
                }
                // if ((t.m === alarmaCrono.m && t.s === alarmaCrono.s && t.h === alarmaCrono.h) || (alarmaCrono.m !== 0 && alarmaCrono.h !== 0 && alarmaCrono.s !== 0)) {
                //     alert("GG");
                // }
                return { s, m, h }
            }), 1000);
        } else if (stop && start === false) {
            ref.current && clearInterval(ref.current);
        }
    }

    useEffect(() => {
        hola();
    }, [start, stop]);

    // useEffect(() => {
    //     setAlarmaCrono(alarma);
    // }, [alarma]);

    useEffect(() => {
        //console.log(tiempo.h === alarmaCrono.h && tiempo.m === alarmaCrono.m && tiempo.s === tiempo.s)
        if (((tiempo.m === alarma.m) && (tiempo.s === alarma.s) && (tiempo.h === alarma.h))) {
            alert("GG");
        }
    }, [tiempo]);

    // if(iniciar){
    //     ref.current && clearInterval(ref.current);
    //     ref.current = setInterval(() => setSegundos(s => s + 1), 1000);
    // }



    return (
        <>
            <h4>Timer:   <small>{tiempo.h}</small>: <small>{tiempo.m}</small>: <small>{tiempo.s}</small></h4>

            <button >Guardar Vuelta</button>
        </>
    )
}

export default Stopwatch