export type Time = {
    s: number
    m: number
    h: number
}