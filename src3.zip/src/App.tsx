import { useState } from 'react'
import './App.css'
import Stopwatch from './components/Stopwatch'
import { Time } from './TimeType';

function App() {
  const [inicio, setInicio] = useState<boolean>(false);
  const [pausar, setPausar] = useState<boolean>(false);
  //const [alarma, setAlarma] = useState<Time>({ m: 0, s: 0, h: 0 })
  const [alarma, setAlarma] = useState<Time>({ m: -1, s: -1, h: -1 })

  const handleSubmitIniciar = (e: any) => {
    e.preventDefault();
    setInicio(!inicio);
    if (inicio) {
      setPausar(true);
    } else {
      setPausar(false);
    }
  }

  const handleSubmitAlarma = (e: any) => {
    e.preventDefault();
    // Read the form data
    const form = e.target;
    const formData = new FormData(form);

    // Or you can work with it as a plain object:
    const formJson = Object.fromEntries(formData.entries());
    setAlarma({ m: parseInt(formJson.m as string), s: parseInt(formJson.s as string), h: parseInt(formJson.h as string) })
  }


  return (
    <>


      <form id='formIniciar' onSubmit={handleSubmitIniciar}>
        <button className=''>{!inicio ? "Iniciar Tiempo" : "Pausar Tiempo"}</button>
      </form>

      <form id='formIniciar' onSubmit={handleSubmitAlarma}>
        <input type="number" required min={0} step={1} name="h" id="" placeholder='horas' />
        <input type="number" required min={0} step={1} name="m" id="" placeholder='minutos' />
        <input type="number" required min={0} step={1} name="s" id="" placeholder='segundos' />
        <button className='' type='submit'>Enviar Alarma</button>
      </form>



      <br />


      <Stopwatch start={inicio} stop={pausar} alarma={alarma} />
    </>
  )
}

export default App
